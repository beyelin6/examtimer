import React, { useRef, useState } from 'react';
import { Bell, Volume2, VolumeX, Upload, Square, RotateCcw, Music, X } from 'lucide-react';
import {
  DEFAULT_SOUND_SETTINGS,
  ExamSoundStage,
  SOUND_PRESETS,
  STAGE_METADATA,
  SoundPresetId,
  SoundSettings,
  deleteCustomAudioFile,
  playStageSound,
  saveCustomAudioFile,
  stopAllSounds,
} from '../utils/soundEngine';

interface SoundSettingsPanelProps {
  settings: SoundSettings;
  onChange: React.Dispatch<React.SetStateAction<SoundSettings>>;
}

const STAGES_ORDER: ExamSoundStage[] = ['ready', 'start', 'warning', 'end'];
const MAX_AUDIO_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

export const SoundSettingsPanel: React.FC<SoundSettingsPanelProps> = ({ settings, onChange }) => {
  const [previewingStage, setPreviewingStage] = useState<ExamSoundStage | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRefs = useRef<Partial<Record<ExamSoundStage, HTMLInputElement | null>>>({});
  const previewTimerRef = useRef<number | null>(null);

  const showMessage = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    window.setTimeout(() => {
      setStatusMessage((prev) => (prev?.text === text ? null : prev));
    }, 3500);
  };

  const handleStopPreview = () => {
    stopAllSounds();
    setPreviewingStage(null);
    if (previewTimerRef.current) {
      window.clearTimeout(previewTimerRef.current);
      previewTimerRef.current = null;
    }
  };

  const handlePreview = async (stage: ExamSoundStage) => {
    if (previewingStage === stage) {
      handleStopPreview();
      return;
    }

    handleStopPreview();
    const stageConfig = settings.stages[stage];
    if (stageConfig.preset === 'mute') {
      showMessage('error', '此階段已設為靜音，請先選擇其他鈴聲即可試聽');
      return;
    }

    const previewVolume = settings.volume > 0 ? settings.volume : 0.8;
    setPreviewingStage(stage);
    await playStageSound(
      stage,
      { ...settings, volume: previewVolume },
      { ignoreMute: true, stopPrevious: true }
    );

    const estimatedDurationMs =
      stageConfig.preset === 'school_chime'
        ? 5500
        : stageConfig.preset === 'classic_bell'
          ? 3400
          : stageConfig.preset === 'custom'
            ? 8000
            : 1800;

    previewTimerRef.current = window.setTimeout(() => {
      setPreviewingStage((current) => (current === stage ? null : current));
    }, estimatedDurationMs);
  };

  const handlePresetChange = (stage: ExamSoundStage, preset: SoundPresetId) => {
    onChange((prev) => ({
      ...prev,
      stages: {
        ...prev.stages,
        [stage]: {
          ...prev.stages[stage],
          preset,
        },
      },
    }));
  };

  const handleUploadCustomAudio = async (stage: ExamSoundStage, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      showMessage('error', '請選擇音訊檔案（MP3、WAV、OGG 等格式）');
      return;
    }

    if (file.size > MAX_AUDIO_SIZE_BYTES) {
      showMessage('error', '音檔大小請勿超過 10 MB');
      return;
    }

    try {
      await saveCustomAudioFile(stage, file);
      onChange((prev) => ({
        ...prev,
        stages: {
          ...prev.stages,
          [stage]: {
            preset: 'custom',
            customFileName: file.name,
          },
        },
      }));
      showMessage('success', `已載入「${file.name}」為${STAGE_METADATA[stage].title}`);
    } catch {
      showMessage('error', '儲存音檔失敗，請再試一次');
    }
  };

  const handleRemoveCustomAudio = async (stage: ExamSoundStage) => {
    await deleteCustomAudioFile(stage);
    onChange((prev) => ({
      ...prev,
      stages: {
        ...prev.stages,
        [stage]: {
          preset: DEFAULT_SOUND_SETTINGS.stages[stage].preset,
          customFileName: undefined,
        },
      },
    }));
    showMessage('success', `已移除自訂音檔，恢復為預設鈴聲`);
  };

  const handleResetDefaults = async () => {
    handleStopPreview();
    await Promise.all(STAGES_ORDER.map((stage) => deleteCustomAudioFile(stage)));
    onChange(DEFAULT_SOUND_SETTINGS);
    showMessage('success', '已恢復所有階段的預設響鈴聲音');
  };

  const volumePercent = Math.round(settings.volume * 100);

  return (
    <div id="sound-settings-panel" className="bg-white p-6 rounded-[2rem] shadow-sm border-2 border-amber-100">
      <div className="flex items-center justify-between gap-2 mb-4">
        <h2 className="text-xl font-black flex items-center gap-2 text-amber-600">
          <Bell className="w-6 h-6" />
          響鈴聲音設定
        </h2>
        <div className="flex items-center gap-2">
          {previewingStage && (
            <button
              onClick={handleStopPreview}
              className="flex items-center gap-1 px-2.5 py-1 bg-red-100 text-red-600 hover:bg-red-200 rounded-lg text-xs font-bold transition-colors"
              title="停止目前試聽"
            >
              <Square className="w-3 h-3 fill-current" /> 停止
            </button>
          )}
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1 px-2.5 py-1 bg-gray-100 text-gray-500 hover:bg-gray-200 hover:text-gray-700 rounded-lg text-xs font-bold transition-colors"
            title="恢復預設鈴聲"
          >
            <RotateCcw className="w-3 h-3" /> 預設
          </button>
        </div>
      </div>

      {/* 主音量與靜音控制 */}
      <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-100 mb-4">
        <div className="flex items-center justify-between gap-3 mb-2">
          <button
            onClick={() =>
              onChange((prev) => ({
                ...prev,
                muted: !prev.muted,
              }))
            }
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              settings.muted
                ? 'bg-red-100 text-red-600 hover:bg-red-200'
                : 'bg-amber-200/70 text-amber-800 hover:bg-amber-200'
            }`}
          >
            {settings.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {settings.muted ? '已靜音' : '響鈴開啟'}
          </button>
          <span className="text-sm font-black text-amber-800 tabular-nums">
            音量 {settings.muted ? '0%' : `${volumePercent}%`}
          </span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={settings.muted ? 0 : volumePercent}
          onChange={(e) => {
            const val = Number(e.target.value) / 100;
            onChange((prev) => ({
              ...prev,
              volume: val,
              muted: val === 0 ? true : false,
            }));
          }}
          className="w-full accent-amber-500 cursor-pointer h-2 rounded-lg"
          aria-label="響鈴主音量"
        />
        {settings.muted && (
          <p className="text-xs font-bold text-red-500 mt-1.5">
            ⚠️ 目前為靜音模式，考試進行時將不會發出任何鈴聲。
          </p>
        )}
      </div>

      {/* 操作提示訊息 */}
      {statusMessage && (
        <div
          className={`mb-4 px-3 py-2 rounded-xl text-xs font-bold ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-red-50 text-red-600 border border-red-200'
          }`}
        >
          {statusMessage.text}
        </div>
      )}

      {/* 各階段鈴聲設定 */}
      <div className="space-y-3">
        {STAGES_ORDER.map((stage) => {
          const meta = STAGE_METADATA[stage];
          const config = settings.stages[stage];
          const isPlayingThis = previewingStage === stage;

          return (
            <div key={stage} className={`p-3.5 rounded-2xl border-2 transition-colors ${meta.borderClass}`}>
              <div className="flex items-center justify-between gap-2 mb-2">
                <div>
                  <span className={`inline-block px-2 py-0.5 rounded-lg text-xs font-black ${meta.badgeClass}`}>
                    {meta.title}
                  </span>
                  <p className="text-xs text-gray-500 font-medium mt-0.5">{meta.subtitle}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  <input
                    ref={(el) => {
                      fileInputRefs.current[stage] = el;
                    }}
                    type="file"
                    accept="audio/*"
                    className="hidden"
                    onChange={(e) => handleUploadCustomAudio(stage, e)}
                  />
                  <button
                    onClick={() => fileInputRefs.current[stage]?.click()}
                    className="p-2 bg-white hover:bg-gray-100 text-gray-600 rounded-xl border border-gray-200 transition-colors"
                    title="上傳自訂鈴聲音檔 (MP3 / WAV)"
                  >
                    <Upload className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handlePreview(stage)}
                    className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold transition-colors shadow-sm ${
                      isPlayingThis
                        ? 'bg-red-500 text-white hover:bg-red-600'
                        : 'bg-white text-amber-700 hover:bg-amber-100 border border-amber-200'
                    }`}
                    title={isPlayingThis ? '停止試聽' : '試聽此階段鈴聲'}
                  >
                    {isPlayingThis ? (
                      <>
                        <Square className="w-3.5 h-3.5 fill-current" /> 停止
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" /> 試聽
                      </>
                    )}
                  </button>
                </div>
              </div>

              <select
                value={config.preset}
                onChange={(e) => handlePresetChange(stage, e.target.value as SoundPresetId)}
                className="w-full p-2.5 border-2 border-white bg-white rounded-xl focus:ring-4 focus:ring-amber-100 focus:border-amber-400 outline-none text-sm font-bold text-gray-700 shadow-xs"
              >
                {SOUND_PRESETS.map((option) => (
                  <option key={option.id} value={option.id}>
                    {option.label}
                  </option>
                ))}
                {config.customFileName && (
                  <option value="custom">📁 自訂音檔：{config.customFileName}</option>
                )}
              </select>

              {config.customFileName && (
                <div className="mt-2 flex items-center justify-between gap-2 bg-white/80 px-2.5 py-1.5 rounded-lg border border-amber-200/70">
                  <span className="text-xs font-bold text-amber-800 flex items-center gap-1 truncate">
                    <Music className="w-3.5 h-3.5 flex-shrink-0" />
                    <span className="truncate">{config.customFileName}</span>
                  </span>
                  <button
                    onClick={() => handleRemoveCustomAudio(stage)}
                    className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                    title="移除自訂音檔"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
