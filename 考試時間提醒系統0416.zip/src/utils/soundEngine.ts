// Web Audio API 響鈴音效引擎與自訂音檔儲存

export type ExamSoundStage = 'ready' | 'start' | 'warning' | 'end';

export type SoundPresetId =
  | 'school_chime'
  | 'triad'
  | 'ding_dong'
  | 'gentle_bell'
  | 'alert_beep'
  | 'classic_bell'
  | 'mute'
  | 'custom';

export interface StageSoundConfig {
  preset: SoundPresetId;
  customFileName?: string;
}

export interface SoundSettings {
  volume: number; // 0 to 1
  muted: boolean;
  stages: Record<ExamSoundStage, StageSoundConfig>;
}

export interface SoundPresetOption {
  id: SoundPresetId;
  label: string;
  description: string;
}

export const SOUND_PRESETS: SoundPresetOption[] = [
  { id: 'school_chime', label: '🏫 校園西敏寺鐘聲', description: '經典國小上下課鐘聲旋律' },
  { id: 'triad', label: '🎵 輕快三連音', description: '明亮上揚的 Mi-Sol-Do 預備音' },
  { id: 'ding_dong', label: '🔔 清脆叮咚聲', description: '柔和清楚的叮咚提醒音' },
  { id: 'gentle_bell', label: '✨ 柔和木琴聲', description: '溫暖不刺耳的木琴和弦音' },
  { id: 'alert_beep', label: '🚨 清晰警示音', description: '節奏分明的短促提示音' },
  { id: 'classic_bell', label: '⏰ 傳統電鈴聲', description: '雙響長聲鈴響，收卷最醒目' },
  { id: 'mute', label: '🔇 靜音（不響鈴）', description: '此階段僅顯示畫面，不播放聲音' },
];

export const DEFAULT_SOUND_SETTINGS: SoundSettings = {
  volume: 0.8,
  muted: false,
  stages: {
    ready: { preset: 'triad' },
    start: { preset: 'school_chime' },
    warning: { preset: 'ding_dong' },
    end: { preset: 'classic_bell' },
  },
};

export const STAGE_METADATA: Record<
  ExamSoundStage,
  { title: string; subtitle: string; badgeClass: string; borderClass: string }
> = {
  ready: {
    title: '考前 2 分鐘預備鈴',
    subtitle: '提醒小朋友回座位準備',
    badgeClass: 'bg-orange-100 text-orange-700',
    borderClass: 'border-orange-100 bg-orange-50/40',
  },
  start: {
    title: '考試開始鐘聲',
    subtitle: '時間一到開始作答',
    badgeClass: 'bg-green-100 text-green-700',
    borderClass: 'border-green-100 bg-green-50/40',
  },
  warning: {
    title: '結束前 5 分鐘提醒',
    subtitle: '提醒檢查考卷與最後衝刺',
    badgeClass: 'bg-amber-100 text-amber-700',
    borderClass: 'border-amber-100 bg-amber-50/40',
  },
  end: {
    title: '考試結束鐘聲',
    subtitle: '提醒立刻停筆等待收卷',
    badgeClass: 'bg-red-100 text-red-700',
    borderClass: 'border-red-100 bg-red-50/40',
  },
};

// --- 共用 AudioContext 與停止管理 ---
let sharedAudioCtx: AudioContext | null = null;
let activeTimeouts: number[] = [];
let activeAudioElement: HTMLAudioElement | null = null;
let activeNodes: AudioNode[] = [];

const getAudioContext = (): AudioContext | null => {
  const AudioContextClass =
    window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new AudioContextClass();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
};

export const unlockAudioContext = () => {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.02);
  } catch {
    // 忽略瀏覽器解鎖失敗
  }
};

export const stopAllSounds = () => {
  activeTimeouts.forEach((id) => window.clearTimeout(id));
  activeTimeouts = [];

  if (activeAudioElement) {
    activeAudioElement.pause();
    activeAudioElement.currentTime = 0;
    activeAudioElement = null;
  }

  activeNodes.forEach((node) => {
    try {
      if ('stop' in node && typeof (node as OscillatorNode).stop === 'function') {
        (node as OscillatorNode).stop();
      }
      node.disconnect();
    } catch {
      // 已停止的節點略過
    }
  });
  activeNodes = [];
};

const scheduleTone = (
  delayMs: number,
  frequency: number,
  type: OscillatorType,
  duration: number,
  baseVol: number,
  masterVolume: number,
  attackSec = 0.015
) => {
  const timerId = window.setTimeout(() => {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const targetVol = Math.max(0.001, Math.min(1, baseVol * masterVolume));

    osc.type = type;
    osc.frequency.setValueAtTime(frequency, now);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(targetVol, now + attackSec);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    activeNodes.push(osc, gain);
    osc.onended = () => {
      activeNodes = activeNodes.filter((n) => n !== osc && n !== gain);
    };

    osc.start(now);
    osc.stop(now + duration + 0.02);
  }, delayMs);

  activeTimeouts.push(timerId);
};

// 模擬傳統電鈴震盪效果
const scheduleClassicBellRing = (delayMs: number, durationSec: number, masterVolume: number) => {
  const timerId = window.setTimeout(() => {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const carrier = ctx.createOscillator();
    const overtone = ctx.createOscillator();
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    const masterGain = ctx.createGain();

    const targetVol = Math.max(0.001, Math.min(0.65, 0.35 * masterVolume));

    carrier.type = 'triangle';
    carrier.frequency.setValueAtTime(880, now);

    overtone.type = 'sine';
    overtone.frequency.setValueAtTime(1760, now);

    // 18Hz 振幅調變模擬電鈴敲擊顫音
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(18, now);
    lfoGain.gain.setValueAtTime(targetVol * 0.45, now);

    masterGain.gain.setValueAtTime(0.001, now);
    masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.03);
    masterGain.gain.setValueAtTime(targetVol, now + Math.max(0.05, durationSec - 0.15));
    masterGain.gain.exponentialRampToValueAtTime(0.001, now + durationSec);

    lfo.connect(lfoGain);
    lfoGain.connect(masterGain.gain);
    carrier.connect(masterGain);
    overtone.connect(masterGain);
    masterGain.connect(ctx.destination);

    const nodes: AudioNode[] = [carrier, overtone, lfo, lfoGain, masterGain];
    activeNodes.push(...nodes);
    carrier.onended = () => {
      activeNodes = activeNodes.filter((n) => !nodes.includes(n));
    };

    carrier.start(now);
    overtone.start(now);
    lfo.start(now);

    carrier.stop(now + durationSec + 0.02);
    overtone.stop(now + durationSec + 0.02);
    lfo.stop(now + durationSec + 0.02);
  }, delayMs);

  activeTimeouts.push(timerId);
};

// --- IndexedDB 儲存自訂音檔 ---
const DB_NAME = 'exam_timer_sounds_db';
const STORE_NAME = 'custom_sounds';

const openSoundDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const saveCustomAudioFile = async (stage: ExamSoundStage, file: File): Promise<void> => {
  const db = await openSoundDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(file, stage);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
};

export const getCustomAudioBlob = async (stage: ExamSoundStage): Promise<Blob | null> => {
  try {
    const db = await openSoundDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).get(stage);
      req.onsuccess = () => resolve((req.result as Blob) || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
};

export const deleteCustomAudioFile = async (stage: ExamSoundStage): Promise<void> => {
  try {
    const db = await openSoundDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(stage);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // 忽略清除錯誤
  }
};

// --- 播放指定預設音效 ---
export const playPresetSound = (preset: SoundPresetId, volume: number) => {
  const vol = Math.max(0, Math.min(1, volume));
  if (preset === 'mute' || vol <= 0) return;

  switch (preset) {
    case 'school_chime': {
      // 西敏寺鐘聲前兩句：Mi - Do - Re - Sol (低) | Sol (低) - Re - Mi - Do
      const notes = [
        { freq: 659.25, delay: 0, dur: 0.65 },    // E5
        { freq: 523.25, delay: 500, dur: 0.65 },  // C5
        { freq: 587.33, delay: 1000, dur: 0.65 }, // D5
        { freq: 392.0, delay: 1500, dur: 1.1 },   // G4
        { freq: 392.0, delay: 2400, dur: 0.65 },  // G4
        { freq: 587.33, delay: 2900, dur: 0.65 }, // D5
        { freq: 659.25, delay: 3400, dur: 0.65 }, // E5
        { freq: 523.25, delay: 3900, dur: 1.3 },  // C5
      ];
      notes.forEach((n) => {
        scheduleTone(n.delay, n.freq, 'sine', n.dur, 0.55, vol, 0.02);
        scheduleTone(n.delay, n.freq * 2, 'triangle', n.dur * 0.7, 0.14, vol, 0.01);
      });
      break;
    }

    case 'triad': {
      // 輕快三連音 Mi - Sol - Do
      scheduleTone(0, 659.25, 'sine', 0.25, 0.55, vol);
      scheduleTone(260, 783.99, 'sine', 0.25, 0.55, vol);
      scheduleTone(520, 1046.5, 'sine', 0.6, 0.65, vol);
      break;
    }

    case 'ding_dong': {
      // 柔和清脆叮咚聲
      scheduleTone(0, 880, 'sine', 0.65, 0.55, vol);
      scheduleTone(0, 1760, 'sine', 0.3, 0.12, vol);
      scheduleTone(500, 698.46, 'sine', 0.9, 0.55, vol);
      scheduleTone(500, 1396.91, 'sine', 0.4, 0.1, vol);
      break;
    }

    case 'gentle_bell': {
      // 柔和木琴和弦 (C5 - E5 - G5 - C6)
      const chord = [523.25, 659.25, 783.99, 1046.5];
      chord.forEach((freq, idx) => {
        scheduleTone(idx * 180, freq, 'triangle', 0.7, 0.45, vol, 0.01);
        scheduleTone(idx * 180, freq * 2, 'sine', 0.35, 0.12, vol, 0.008);
      });
      break;
    }

    case 'alert_beep': {
      // 清晰三聲警示音
      scheduleTone(0, 987.77, 'sine', 0.22, 0.55, vol);
      scheduleTone(320, 987.77, 'sine', 0.22, 0.55, vol);
      scheduleTone(640, 1318.51, 'sine', 0.5, 0.6, vol);
      break;
    }

    case 'classic_bell': {
      // 傳統電鈴雙響
      scheduleClassicBellRing(0, 1.4, vol);
      scheduleClassicBellRing(1750, 1.5, vol);
      break;
    }

    default:
      break;
  }
};

// --- 依階段設定播放音效（支援自訂音檔與預設鈴聲） ---
export const playStageSound = async (
  stage: ExamSoundStage,
  settings: SoundSettings,
  options?: { ignoreMute?: boolean; stopPrevious?: boolean }
) => {
  if (!options?.ignoreMute && settings.muted) return;
  if (settings.volume <= 0) return;

  if (options?.stopPrevious) {
    stopAllSounds();
  }

  const stageConfig = settings.stages[stage];
  if (!stageConfig || stageConfig.preset === 'mute') return;

  if (stageConfig.preset === 'custom') {
    const blob = await getCustomAudioBlob(stage);
    if (blob) {
      const url = URL.createObjectURL(blob);
      const audio = new Audio(url);
      audio.volume = Math.max(0, Math.min(1, settings.volume));
      activeAudioElement = audio;
      audio.onended = () => {
        URL.revokeObjectURL(url);
        if (activeAudioElement === audio) {
          activeAudioElement = null;
        }
      };
      audio.onerror = () => {
        URL.revokeObjectURL(url);
        if (activeAudioElement === audio) {
          activeAudioElement = null;
        }
      };
      audio.play().catch(() => {
        URL.revokeObjectURL(url);
      });
      return;
    }
    // 若找不到自訂音檔，回退到該階段預設音
    playPresetSound(DEFAULT_SOUND_SETTINGS.stages[stage].preset, settings.volume);
    return;
  }

  playPresetSound(stageConfig.preset, settings.volume);
};

export const loadSoundSettings = (): SoundSettings => {
  try {
    const raw = localStorage.getItem('exam_sound_settings');
    if (!raw) return DEFAULT_SOUND_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<SoundSettings>;
    return {
      volume: typeof parsed.volume === 'number' ? Math.max(0, Math.min(1, parsed.volume)) : DEFAULT_SOUND_SETTINGS.volume,
      muted: typeof parsed.muted === 'boolean' ? parsed.muted : DEFAULT_SOUND_SETTINGS.muted,
      stages: {
        ready: parsed.stages?.ready || DEFAULT_SOUND_SETTINGS.stages.ready,
        start: parsed.stages?.start || DEFAULT_SOUND_SETTINGS.stages.start,
        warning: parsed.stages?.warning || DEFAULT_SOUND_SETTINGS.stages.warning,
        end: parsed.stages?.end || DEFAULT_SOUND_SETTINGS.stages.end,
      },
    };
  } catch {
    return DEFAULT_SOUND_SETTINGS;
  }
};
